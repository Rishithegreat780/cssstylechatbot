# coronabot-chatterbot
CoronaBot is a chat bot for answering question regarding Coronavirus

Tutorial - https://studygyaan.com/uncategorised/create-web-based-chatbot-in-python-django-flask

`pip install Flask`

`pip install chatterbot`

`pip install chatterbot-corpus`

or 

`pip install -r requirements.txt`

![Chatbot](https://studygyaan.com/wp-content/uploads/2020/03/Chatbot-in-Python.png?style=centerme)
