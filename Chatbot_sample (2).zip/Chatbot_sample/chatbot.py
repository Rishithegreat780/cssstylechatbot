from chatterbot import ChatBot
from chatterbot.trainers import ChatterBotCorpusTrainer, ListTrainer
from chatterbot.logic import BestMatch

# Create a ChatBot instance
chatbot = ChatBot(
    'CoronaBot',
    storage_adapter='chatterbot.storage.SQLStorageAdapter',
    logic_adapters=[
        'chatterbot.logic.MathematicalEvaluation',
        'chatterbot.logic.TimeLogicAdapter'
    ],
    database_uri='sqlite:///database.sqlite3'
)

# Remove the existing logic adapters
chatbot.logic_adapters = []

# Training With Corpus
trainer_corpus = ChatterBotCorpusTrainer(chatbot)
trainer_corpus.train('chatterbot.corpus.english')

# Create the BestMatch logic adapter with chatbot instance
best_match_logic_adapter = BestMatch(
    chatbot=chatbot,
    default_response='I am sorry, but I do not understand. I am still learning.',
    maximum_similarity_threshold=0.90
)

# Append the BestMatch logic adapter to the logic_adapters list
chatbot.logic_adapters.append(best_match_logic_adapter)

# Check if the logic_adapters list has enough elements
if len(chatbot.logic_adapters) > 1:
    # Set the maximum similarity threshold for the BestMatch logic adapter
    chatbot.logic_adapters[1].statement_comparison_function.maximum_similarity_threshold = 0.5

# Training With Own Questions
list_trainer = ListTrainer(chatbot)

training_data_quesans = open('training_data/ques_ans.txt').read().splitlines()
training_data_personal = open('training_data/personal_ques.txt').read().splitlines()

training_data = training_data_quesans + training_data_personal

# Train the chatbot with the custom training data
list_trainer.train(training_data)

# Run your application or interact with the chatbot as needed
