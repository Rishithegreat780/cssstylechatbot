"""
Example sentences to test spaCy and its language models.

>>> from spacy.lang.hr.examples import sentences
>>> docs = nlp.pipe(sentences)
"""

sentences = [
    "Ovo je rečenica.",
    "Kako se popravlja auto?",
    "Zagreb je udaljen od Ljubljane svega 150 km.",
    "Nećete vjerovati što se dogodilo na ovogodišnjem festivalu!",
    "Budućnost Apple je upitna nakon dugotrajnog pada vrijednosti dionica firme.",
    "Trgovina oružjem predstavlja prijetnju za globalni mir.",
]
