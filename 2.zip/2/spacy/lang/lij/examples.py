"""
Example sentences to test spaCy and its language models.

>>> from spacy.lang.lij.examples import sentences
>>> docs = nlp.pipe(sentences)
"""


sentences = [
    "Sciusciâ e sciorbî no se peu.",
    "Graçie di çetroin, che me son arrivæ.",
    "Vegnime apreuvo, che ve fasso pescâ di òmmi.",
    "Bella pe sempre l'ægua inta conchetta quande unn'agoggia d'ægua a se â trapaña.",
]
