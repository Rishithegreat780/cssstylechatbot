import pyodbc
import re
import datetime

conn = pyodbc.connect('Driver={SQL Server};Server=ARVIND\MSSQLSERVER01;Database=master;Trusted_Connection=yes;')

def process_asa_query(query):
    country, time_period = extract_asa_info(query)

    if country is None or time_period is None:
        response = "Please provide the country and time period for calculating ASA."
    else:
        if time_period == 'month':
            time_range = None  # Default to None
            if re.search(r'\b(\d+)\s*month', query, re.IGNORECASE):
                match = re.search(r'\b(\d+)\s*month', query, re.IGNORECASE)
                num_months = int(match.group(1))
                time_range = num_months
                # Calculate the start and end dates of the desired month range
                end_date = datetime.date.today()
                start_month = end_date.month - num_months
                start_year = end_date.year

                if start_month <= 0:
                    start_year -= 1
                    start_month += 12

                start_date = datetime.date(start_year, start_month, 1)
                date_range = f"{start_date.strftime('%d-%b-%Y')} to {end_date.strftime('%d-%b-%Y')}"
        elif time_period == 'week':
            time_range = None  # Default to None
            if re.search(r'\b(\d+)\s*week', query, re.IGNORECASE):
                match = re.search(r'\b(\d+)\s*week', query, re.IGNORECASE)
                num_weeks = int(match.group(1))
                time_range = num_weeks
                # Calculate the start and end dates of the desired weeks
                end_date = datetime.date.today()
                start_date = end_date - datetime.timedelta(weeks=num_weeks)
                date_range = f"{start_date.strftime('%d-%b-%Y')} to {end_date.strftime('%d-%b-%Y')}"
        elif time_period == 'day':
            time_range = None  # Default to None
            if re.search(r'\b(\d+)\s*day', query, re.IGNORECASE):
                match = re.search(r'\b(\d+)\s*day', query, re.IGNORECASE)
                num_days = int(match.group(1))
                time_range = num_days
                # Calculate the start and end dates of the desired days
                end_date = datetime.date.today()
                start_date = end_date - datetime.timedelta(days=num_days)
                date_range = f"{start_date.strftime('%d-%b-%Y')} to {end_date.strftime('%d-%b-%Y')}"
        else:
            response = "Invalid time period specified. Please specify either 'month', 'week', or 'day'."
            return response

        group_by_format = {
            'month': "FORMAT(Date, 'MM-yyyy')",
            'week': "CONCAT('Week-', DATEPART(WEEK, Date))",
            'day': "CONVERT(DATE, Date)"
        }

        max_date_query = "SELECT MAX(Date) FROM ASA"
        cursor = conn.cursor()
        cursor.execute(max_date_query)
        max_date_result = cursor.fetchone()
        if max_date_result[0]:
            max_date = datetime.datetime.strptime(max_date_result[0], '%Y-%m-%d').date()
        else:
            max_date = datetime.date.today()

        if end_date > max_date:
            end_date = max_date

        sql_query = f"SELECT Country, {group_by_format[time_period]} AS [Group], AVG(ASA) AS ASA FROM ASA WHERE Country = '{country}' AND Date >= '{start_date}' AND Date <= '{end_date}' GROUP BY Country, {group_by_format[time_period]}"

        print(f"Executing SQL query: {sql_query}")

        cursor.execute(sql_query)
        rows = cursor.fetchall()

        if len(rows) == 0:
            response = f"No data available for {country} over the specified time period ({time_period})."
            return response

        response = f"The average speed of answer (ASA) for {country} over the specified time period ({time_period}) ({date_range}):"
        response += "<table style='border-collapse: collapse;'>"
        response += "<tr><th style='border: 1px solid black; padding: 5px;'>Country</th><th style='border: 1px solid black; padding: 5px;'>Group</th><th style='border: 1px solid black; padding: 5px;'>ASA</th></tr>"

        for row in rows:
            country = row.Country
            group = row.Group
            asa = row.ASA

            response += "<tr><td style='border: 1px solid black; padding: 5px;'>{}</td><td style='border: 1px solid black; padding: 5px;'>{}</td><td style='border: 1px solid black; padding: 5px;'>{}</td></tr>".format(country, group, asa)

        response += "</table>"

        response += f"\n\n\nMAX data updated till: {end_date.strftime('%d-%b-%Y')}"

    return response

def extract_asa_info(query):
    country = None
    time_period = None

    if re.search(r'ASA for ([\w\s]+) (?:for|in) last', query, re.IGNORECASE):
        match = re.search(r'ASA for ([\w\s]+) (?:for|in) last', query, re.IGNORECASE)
        country = match.group(1)

    if re.search(r'(month|week|day)', query, re.IGNORECASE):
        match = re.search(r'(month|week|day)', query, re.IGNORECASE)
        time_period = match.group(1)

    return country, time_period
