import pyodbc
import re
import datetime
from dateutil.relativedelta import relativedelta
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import base64
from io import BytesIO
import numpy as np

conn = pyodbc.connect('Driver={SQL Server};Server=ARVIND\MSSQLSERVER01;Database=master;Trusted_Connection=yes;')

def process_asa_query(query):
    country, time_period = extract_asa_info(query)

    if country is None or time_period is None:
        response = "Please provide the country and time period for calculating ASA."
    else:
        if time_period == 'month':
            time_range = None  # Default to None
            if re.search(r'\b(\d+)\s*month', query, re.IGNORECASE):
                match = re.search(r'\b(\d+)\s*month', query, re.IGNORECASE)
                num_months = int(match.group(1))
                time_range = num_months
                # Calculate the start and end dates of the desired month range
                end_date = datetime.date.today()
                start_date = end_date - relativedelta(months=num_months - 1)
                start_date = start_date.replace(day=1)  # Set the day to 1
                date_range = f"{start_date.strftime('%d-%b-%Y')} to {end_date.strftime('%d-%b-%Y')}"
        elif time_period == 'week':
            time_range = None  # Default to None
            if re.search(r'\b(\d+)\s*week', query, re.IGNORECASE):
                match = re.search(r'\b(\d+)\s*week', query, re.IGNORECASE)
                num_weeks = int(match.group(1))
                time_range = num_weeks
                # Calculate the start and end dates of the desired weeks
                end_date = datetime.date.today()
                start_date = end_date - datetime.timedelta(weeks=num_weeks)
                date_range = f"{start_date.strftime('%d-%b-%Y')} to {end_date.strftime('%d-%b-%Y')}"
        elif time_period == 'day':
            time_range = None  # Default to None
            if re.search(r'\b(\d+)\s*day', query, re.IGNORECASE):
                match = re.search(r'\b(\d+)\s*day', query, re.IGNORECASE)
                num_days = int(match.group(1))
                time_range = num_days
                # Calculate the start and end dates of the desired days
                end_date = datetime.date.today()
                start_date = end_date - datetime.timedelta(days=num_days)
                date_range = f"{start_date.strftime('%d-%b-%Y')} to {end_date.strftime('%d-%b-%Y')}"
        else:
            response = "Invalid time period specified. Please specify either 'month', 'week', or 'day'."
            return response

        group_by_format = {
            'month': "FORMAT(Date, 'MM-yyyy')",
            'week': "CONCAT('Week-', DATEPART(WEEK, Date))",
            'day': "CONVERT(DATE, Date)"
        }

        max_date_query = "SELECT MAX(Date) FROM ASA"
        cursor = conn.cursor()
        cursor.execute(max_date_query)
        max_date_result = cursor.fetchone()
        if max_date_result[0]:
            max_date = datetime.datetime.strptime(max_date_result[0], '%Y-%m-%d').date()
        else:
            max_date = datetime.date.today()

        if end_date > max_date:
            end_date = max_date

        if time_period == 'month':
            order_by_format = "MIN(Date)"
        elif time_period == 'week':
            order_by_format = "MIN(Date)"
        elif time_period == 'day':
            order_by_format = "Date"

        sql_query = f"SELECT Country, {group_by_format[time_period]} AS [Group], AVG(ASA) AS ASA FROM ASA WHERE Country = '{country}' AND Date >= '{start_date}' AND Date <= '{end_date}' GROUP BY Country, {group_by_format[time_period]} ORDER BY {order_by_format} ASC"

        print(f"Executing SQL query: {sql_query}")

        cursor.execute(sql_query)
        rows = cursor.fetchall()

        if len(rows) == 0:
            response = f"No data available for {country} over the specified time period ({time_period})."
            return response

        # Extracting the data for the graph
        groups = []
        asa_values = []
        for row in rows:
            group = row.Group
            asa = row.ASA
            groups.append(group)
            asa_values.append(asa)

        # Normalizing ASA values
        normalized_asa_values = (asa_values - np.min(asa_values)) / (np.max(asa_values) - np.min(asa_values))

        # Creating the colormap
        colormap = plt.cm.get_cmap('YlOrRd')

        # Assigning colors based on normalized ASA values
        colors = []
        for value in normalized_asa_values:
            if value >= 0.7:
                colors.append('r')  # Red
            elif value >= 0.4:
                colors.append('orange')  # Amber
            else:
                colors.append('g')  # Green

        # Creating the bar graph with color coding
        plt.figure()  # Create a new figure
        plt.bar(groups, asa_values, color=colors)
        plt.xlabel('Group')
        plt.ylabel('ASA')
        plt.title(f"Average Speed of Answer (ASA) for {country} ({time_period})")
        plt.xticks(rotation=90)
        plt.tight_layout()

        # Saving the graph as an image
        buffer = BytesIO()
        plt.savefig(buffer, format='png')
        buffer.seek(0)
        image_data = base64.b64encode(buffer.read()).decode('utf-8')

        # Constructing the HTML for displaying the graph
        graph_html = f"<img src='data:image/png;base64,{image_data}' alt='ASA Graph' style='display: block; margin-left: auto; margin-right: auto;'>"

        # Constructing the HTML for displaying the table
        table_html = "<table style='border-collapse: collapse;'>"
        table_html += "<tr><th style='border: 1px solid black; padding: 5px;'>Country</th><th style='border: 1px solid black; padding: 5px;'>Group</th><th style='border: 1px solid black; padding: 5px;'>ASA</th></tr>"
        for row in rows:
            country = row.Country
            group = row.Group
            asa = row.ASA
            table_html += "<tr><td style='border: 1px solid black; padding: 5px;'>{}</td><td style='border: 1px solid black; padding: 5px;'>{}</td><td style='border: 1px solid black; padding: 5px;'>{}</td></tr>".format(
                country, group, asa)
        table_html += "</table>"

        # Constructing the final response with both the graph and table
        response = f"The average speed of answer (ASA) for {country} over the specified time period ({time_period}) ({date_range}):<br><br>"
        response += graph_html + "<br><br>"
        response += table_html

        response += f"<br><br>MAX data updated till: {end_date.strftime('%d-%b-%Y')}"

    return response

def extract_asa_info(query):
    country = None
    time_period = None

    if re.search(r'ASA for ([\w\s]+) (?:for|in) last', query, re.IGNORECASE):
        match = re.search(r'ASA for ([\w\s]+) (?:for|in) last', query, re.IGNORECASE)
        country = match.group(1)

    if re.search(r'(month|week|day)', query, re.IGNORECASE):
        match = re.search(r'(month|week|day)', query, re.IGNORECASE)
        time_period = match.group(1)

    return country, time_period
